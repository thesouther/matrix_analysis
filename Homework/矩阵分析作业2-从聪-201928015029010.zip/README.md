####  LU Factorization


This program is the assignment 2 for the course Matrix Analysis and Applications.
You can run LU_Factorization.py to gain a result for a given matrix (which you in a data file in the './data' folder).
The description of the files is as follows:
- 'LU_Factorization.py', the main function used to carry out a process of a LU factorization.
- 'tools.py', this file is storing some helper functions;
- './data/test_data1.txt', a file where you can load matrix data;
- './output/', is a folder where you can save LU matrices you got.
